class Online < Section
	validates :url, presence: true
end