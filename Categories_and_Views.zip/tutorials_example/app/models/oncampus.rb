class Oncampus < Section
	validates :days, :times, presence: true
end