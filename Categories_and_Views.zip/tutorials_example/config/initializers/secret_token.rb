# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
TutorialsExample::Application.config.secret_key_base = 'b664ed60b37bbc067406dd471e23ab04051f224c1e04e4f468b1fa2edd8e17a332b6ebad95c552599686ec46a37d3ed5707d5d2c7d28c44ca58d33285a3c362f'
