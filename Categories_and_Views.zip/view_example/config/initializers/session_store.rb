# Be sure to restart your server when you modify this file.

ViewExample::Application.config.session_store :cookie_store, key: '_view_example_session'
