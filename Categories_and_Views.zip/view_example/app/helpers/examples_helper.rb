module ExamplesHelper
end
