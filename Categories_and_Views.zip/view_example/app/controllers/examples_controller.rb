class ExamplesController < ApplicationController
  def index
  end
end
