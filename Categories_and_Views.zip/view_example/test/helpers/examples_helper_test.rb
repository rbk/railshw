require 'test_helper'

class ExamplesHelperTest < ActionView::TestCase
end
