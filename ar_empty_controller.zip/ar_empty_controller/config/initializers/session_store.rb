# Be sure to restart your server when you modify this file.

ArEmptyController::Application.config.session_store :cookie_store, key: '_ar_empty_controller_session'
