module MugsHelper
end
