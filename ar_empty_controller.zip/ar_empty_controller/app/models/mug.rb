class Mug < ActiveRecord::Base
end
