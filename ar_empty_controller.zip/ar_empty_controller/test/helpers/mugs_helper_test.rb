require 'test_helper'

class MugsHelperTest < ActionView::TestCase
end
