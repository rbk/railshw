require 'test_helper'

class MugTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
