require 'test_helper'

class LightsabersHelperTest < ActionView::TestCase
end
