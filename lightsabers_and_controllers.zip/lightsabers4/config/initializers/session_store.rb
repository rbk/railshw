# Be sure to restart your server when you modify this file.

Lightsabers4::Application.config.session_store :cookie_store, key: '_lightsabers4_session'
