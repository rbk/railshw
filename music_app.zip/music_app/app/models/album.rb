class Album < ActiveRecord::Base
	has_many :tracks
	has_many :artists, through: :tracks, uniq: true
	
	has_attached_file :cover
	validates_attachment_content_type :cover, content_type: /\Aimage\/.*\Z/
	
	validates :title, presence: true
	validates :year, presence: true, numericality: true
	
	def duration
		self.tracks.inject(0) {|total,track| total += track.duration}	
	end
end
