class Track < ActiveRecord::Base
  belongs_to :album
  belongs_to :artist
  belongs_to :genre
	
	validates :title, presence: true
	validates :duration, presence: true, numericality: true
	validates :genre_id, :artist_id, :album_id, presence: true
	
	def to_param
		"#{self.id}-#{self.title.gsub(' ', '_').downcase}"
	end
end
