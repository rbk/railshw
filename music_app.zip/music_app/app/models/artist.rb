class Artist < ActiveRecord::Base
	has_many :tracks
	has_many :albums, through: :tracks, uniq: true
	has_many :genres, through: :tracks, uniq: true
	
	validates :name, presence: true
end
