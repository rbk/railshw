class SessionController < ApplicationController
	
	# show the login form
	def new
	end
	
	# authenticate the user and log them in
	def create
		user = User.find_by_username(params[:username])
		if user and user.authenticate(params[:password])
			session[:user_id] = user.id
			redirect_to root_url, notice: "You are now logged in :)"
		else
			flash[:alert] = "Your username or password are not correct :("
			render "new"
		end
	end
	
	# logout
	def destroy
		session[:user_id] = nil
		redirect_to root_url, notice: "You've been logged out :|"
	end
	
end
