class AlbumMailer < ActionMailer::Base
  # default from: "no-reply@musicapp.com"
	
	def album_created(album)
		@album = album
		sleep 10
		mail(from: 'no-reply@musicapp.com', to: 'noah@test.com', subject: 'A new Album has been Created!')
	end
end
