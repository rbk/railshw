module AlbumsHelper
	def show_cover( album, width )
		if album.cover_file_name
			image_tag( album.cover, width: width )
		end
	end
end
