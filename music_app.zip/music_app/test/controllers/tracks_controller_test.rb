require 'test_helper'

class TracksControllerTest < ActionController::TestCase
  setup do
    @track = tracks(:one)
		@album = albums(:one)
		login(:one)
  end

  test "should get index" do
    get :index, album_id: @album.id
    assert_response :success
    assert_not_nil assigns(:tracks)
  end

  test "should get new" do
    get :new, album_id: @album.id
    assert_response :success
  end

  test "should create track" do
    assert_difference('Track.count') do
      post :create, album_id: @album.id, track: { album_id: @track.album_id, artist_id: @track.artist_id, duration: @track.duration, genre_id: @track.genre_id, title: @track.title }
    end

    assert_redirected_to album_track_path(@album,assigns(:track))
  end

  test "should show track" do
    get :show, id: @track, album_id: @album.id
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @track, album_id: @album.id
    assert_response :success
  end

  test "should update track" do
    patch :update, album_id: @album.id, id: @track, track: { album_id: @track.album_id, artist_id: @track.artist_id, duration: @track.duration, genre_id: @track.genre_id, title: @track.title }
    assert_redirected_to album_track_path(@album,assigns(:track))
  end

  test "should destroy track" do
    assert_difference('Track.count', -1) do
      delete :destroy, id: @track, album_id: @album.id
    end

    assert_redirected_to album_tracks_path(@album)
  end
end
