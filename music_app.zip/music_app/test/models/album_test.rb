require 'test_helper'

class AlbumTest < ActiveSupport::TestCase
  test "albums report their duration" do
    album = albums(:one)
		
		total = album.tracks.inject(0) {|tot,track| tot += track.duration}
		
		assert_equal total, album.duration
  end
end
