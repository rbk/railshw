require 'test_helper'

class TracksHelperTest < ActionView::TestCase
end
