require 'test_helper'

class GenresHelperTest < ActionView::TestCase
end
