class CreateTracks < ActiveRecord::Migration
  def change
    create_table :tracks do |t|
      t.string :title
      t.string :duration
      t.references :album, index: true
      t.references :artist, index: true
      t.references :genre, index: true

      t.timestamps
    end
  end
end
