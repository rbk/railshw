require 'test_helper'

class SatellitesHelperTest < ActionView::TestCase
end
