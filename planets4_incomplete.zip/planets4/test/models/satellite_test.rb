require 'test_helper'

class SatelliteTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
