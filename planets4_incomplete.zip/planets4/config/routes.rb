Planets4::Application.routes.draw do
  resources :satellites
end
