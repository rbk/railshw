module SatellitesHelper
end
